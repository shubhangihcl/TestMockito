package com.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetailManager {

    public static void main(String[] args) {
        SpringApplication.run(RetailManager.class, args);
    }
}